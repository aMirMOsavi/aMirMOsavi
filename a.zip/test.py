from github import Github

# First, authenticate with Github using an access token or your username and password
g = Github('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')

# Get the repository where the file is located
repo = g.get_repo("aMirMOsavi/aMirMOsavi")

# Get the file you want to delete
file = repo.get_contents("nap")

# Delete the file
repo.delete_file(file.path, "removing file", file.sha)